package com.klu;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class HomeService {

    @Id
    private int id;
    private String serviceName;
    private String serviceDescription;
    private String serviceStatus; // e.g., "Pending", "In Progress", "Completed"

    // Default constructor
    public HomeService() {}

    // Parameterized constructor
    public HomeService(int id, String serviceName, String serviceDescription, String serviceStatus) {
        this.id = id;
        this.serviceName = serviceName;
        this.serviceDescription = serviceDescription;
        this.serviceStatus = serviceStatus;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceDescription() {
        return serviceDescription;
    }

    public void setServiceDescription(String serviceDescription) {
        this.serviceDescription = serviceDescription;
    }

    public String getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(String serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    @Override
    public String toString() {
        return "HomeService [id=" + id + ", serviceName=" + serviceName + ", serviceDescription=" + serviceDescription 
               + ", serviceStatus=" + serviceStatus + "]";
    }
}
