package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HomeServiceRepo extends JpaRepository<HomeService, Integer> {
    // You can define custom query methods here if needed, for example:
    // List<HomeService> findByServiceName(String serviceName);
}

	

