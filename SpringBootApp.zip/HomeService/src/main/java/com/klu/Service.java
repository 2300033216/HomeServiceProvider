package com.klu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Service
public class Service {
    @Autowired
    private HomeServiceRepo homeServiceRepo;

    @Autowired
    private UserRepo userRepo;

    // Add a new Home Service request
    public String insertHomeService(HomeService homeService) {
        homeServiceRepo.save(homeService);
        return "Home Service Added Successfully!";
    }

    // Update an existing Home Service request
    public String updateHomeService(HomeService homeService) {
        homeServiceRepo.save(homeService);
        return "Home Service Updated Successfully!";
    }

    // Delete a Home Service request by ID
    public String deleteHomeService(int id) {
        if (homeServiceRepo.existsById(id)) {
            homeServiceRepo.deleteById(id);
            return "Home Service Deleted Successfully!";
        } else {
            return "Home Service with ID " + id + " does not exist!";
        }
    }

    // Retrieve all Home Services
    public List<HomeService> getAllHomeServices() {
        return homeServiceRepo.findAll();
    }

    // Add a new user
    public String insertUser(User user) {
        userRepo.save(user);
        return "User Registered Successfully!";
    }

    // Authenticate user login
    public String checkUser(User user) {
        User userRetrieved = userRepo.findByUn(user.getUn());
        if (userRetrieved != null) {
            if (userRetrieved.getPw().equals(user.getPw())) {
                return userRetrieved.getRole(); // Return role: Admin, User, etc.
            } else {
                return "0"; // Password mismatch
            }
        } else {
            return "0"; // User not found
        }
    }
}
