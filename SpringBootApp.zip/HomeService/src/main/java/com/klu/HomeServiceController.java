package com.klu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/api") 
public class HomeServiceController {

    @Autowired
    private Service service;

    // Add a new Home Service request
    @PostMapping("/homeservice")
    public ResponseEntity<String> addHomeService(@RequestBody HomeService homeService) {
        try {
            String result = service.insertHomeService(homeService);
            return new ResponseEntity<>(result, HttpStatus.CREATED);  // HTTP 201 Created
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Update a Home Service request
    @PutMapping("/homeservice")
    public ResponseEntity<String> updateHomeService(@RequestBody HomeService homeService) {
        try {
            String result = service.updateHomeService(homeService);
            return new ResponseEntity<>(result, HttpStatus.OK);  // HTTP 200 OK
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Delete a Home Service by ID
    @DeleteMapping("/homeservice/{id}")
    public ResponseEntity<String> deleteHomeService(@PathVariable("id") int id) {
        try {
            String result = service.deleteHomeService(id);
            return new ResponseEntity<>(result, HttpStatus.NO_CONTENT);  // HTTP 204 No Content
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.NOT_FOUND);  // HTTP 404 Not Found
        }
    }

    // Retrieve all Home Services
    @GetMapping("/homeservice")
    public ResponseEntity<List<HomeService>> getAllHomeServices() {
        try {
            List<HomeService> homeServices = service.getAllHomeServices();
            if (homeServices.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // HTTP 204 No Content
            }
            return new ResponseEntity<>(homeServices, HttpStatus.OK);  // HTTP 200 OK
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  // HTTP 500 Internal Server Error
        }
    }

    // Add a new user (for registration)
    @PostMapping("/user")
    public ResponseEntity<String> addUser(@RequestBody User user) {
        try {
            String result = service.insertUser(user);
            return new ResponseEntity<>(result, HttpStatus.CREATED);  // HTTP 201 Created
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);  // HTTP 400 Bad Request
        }
    }

    // Authenticate user login
    @PostMapping("/check")
    public ResponseEntity<String> validateUser(@RequestBody User user) {
        try {
            String result = service.checkUser(user);
            if ("0".equals(result)) {
                return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);  // HTTP 401 Unauthorized
            }
            return new ResponseEntity<>(result, HttpStatus.OK);  // HTTP 200 OK
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
